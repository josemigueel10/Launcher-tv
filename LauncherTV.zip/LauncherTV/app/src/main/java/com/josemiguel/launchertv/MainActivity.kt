package com.josemiguel.launchertv

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.zIndex
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Launcher(tick.intValue) }
    }

    override fun onResume() {
        super.onResume()
        tick.intValue++
    }
}

data class AppItem(val label: String, val pkg: String, val img: ImageBitmap, val banner: Boolean)

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    fun query(cat: String) =
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)
    return (query(Intent.CATEGORY_LEANBACK_LAUNCHER) + query(Intent.CATEGORY_LAUNCHER))
        .filter { it.activityInfo.packageName != ctx.packageName }
        .distinctBy { it.activityInfo.packageName }
        .map {
            val banner = it.activityInfo.loadBanner(pm)
            val bmp = if (banner != null) banner.toBitmap(320, 180)
            else it.loadIcon(pm).toBitmap(180, 180)
            AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, bmp.asImageBitmap(), banner != null)
        }
        .sortedBy { it.label.lowercase() }
}

fun launchApp(ctx: Context, pkg: String) {
    val pm = ctx.packageManager
    val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
    if (i != null) ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

fun openSystem(ctx: Context, wifi: Boolean) {
    val action = if (wifi) Settings.ACTION_WIFI_SETTINGS else Settings.ACTION_SETTINGS
    try {
        ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
        }
    }
}

fun Modifier.glass(r: Dp): Modifier {
    val s = RoundedCornerShape(r)
    return this
        .clip(s)
        .background(Brush.verticalGradient(listOf(Color.White.copy(.26f), Color.White.copy(.10f))))
        .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(.7f), Color.White.copy(.15f))), s)
}

@Composable
fun Pill(text: String, onClick: () -> Unit) {
    var f by remember { mutableStateOf(false) }
    val s = RoundedCornerShape(50.dp)
    Box(
        Modifier
            .scale(if (f) 1.08f else 1f)
            .glass(50.dp)
            .border(if (f) 2.dp else 0.dp, Color.White, s)
            .onFocusChanged { f = it.isFocused }
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp)
    ) {
        Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Tile(a: AppItem, fr: FocusRequester?, onFocus: () -> Unit, onClick: () -> Unit) {
    var f by remember { mutableStateOf(false) }
    val s = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .zIndex(if (f) 1f else 0f)
            .scale(if (f) 1.08f else 1f)
            .clip(s)
            .background(Color(0xFF22242C))
            .border(if (f) 3.dp else 0.dp, Color.White, s)
            .then(if (fr != null) Modifier.focusRequester(fr) else Modifier)
            .onFocusChanged { f = it.isFocused; if (it.isFocused) onFocus() }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Image(
            a.img, a.label,
            Modifier.fillMaxSize().then(if (a.banner) Modifier else Modifier.padding(14.dp)),
            contentScale = if (a.banner) ContentScale.Crop else ContentScale.Fit
        )
    }
}

@Composable
fun CfgDialog(name: String, onClose: () -> Unit, onName: (String) -> Unit, onSys: () -> Unit) {
    var t by remember { mutableStateOf(name) }
    val s = RoundedCornerShape(28.dp)
    Dialog(onDismissRequest = onClose) {
        Column(
            Modifier.width(440.dp).clip(s).background(Color(0xEE1C1C28))
                .border(1.dp, Color.White.copy(.3f), s).padding(28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Ajustes", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Medium)
            Text("Tu nombre", color = Color.White.copy(.7f), fontSize = 13.sp)
            BasicTextField(
                value = t, onValueChange = { t = it }, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
                cursorBrush = SolidColor(Color.White),
                modifier = Modifier.fillMaxWidth().glass(14.dp).padding(14.dp)
            )
            Pill("Guardar nombre") { onName(t.trim().ifEmpty { "José Miguel" }); onClose() }
            Pill("Ajustes del sistema") { onSys() }
            Pill("Cerrar") { onClose() }
        }
    }
}

@Composable
fun Launcher(tick: Int) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE) }
    var name by remember { mutableStateOf(prefs.getString("nombre", "José Miguel") ?: "José Miguel") }
    var now by remember { mutableStateOf(Calendar.getInstance()) }
    var rot by remember { mutableIntStateOf(0) }
    var showCfg by remember { mutableStateOf(false) }
    var cur by remember { mutableIntStateOf(0) }
    val apps = remember(tick) { loadApps(ctx) }
    val fr = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        var n = 0
        while (true) {
            delay(5000)
            now = Calendar.getInstance()
            n++
            if (n % 8 == 0) rot++
        }
    }
    LaunchedEffect(apps) {
        if (apps.isNotEmpty()) {
            delay(400)
            runCatching { fr.requestFocus() }
        }
    }
    BackHandler(true) { }

    val h = now.get(Calendar.HOUR_OF_DAY)
    val p = when { h in 5..11 -> 0; h in 12..18 -> 1; else -> 2 }
    val words = listOf("buenos días", "buenas tardes", "buenas noches")
    val walls = listOf(
        listOf(R.drawable.wp_m1, R.drawable.wp_m2),
        listOf(R.drawable.wp_t1, R.drawable.wp_t2),
        listOf(R.drawable.wp_n1)
    )
    val wp = walls[p].let { it[rot % it.size] }
    val clock = String.format("%02d:%02d", h, now.get(Calendar.MINUTE))
    val date = SimpleDateFormat("EEEE d 'de' MMMM", Locale("es")).format(now.time).uppercase()

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Crossfade(wp, animationSpec = tween(1200), label = "wp") {
            Image(painterResource(it), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color.Black.copy(.45f), Color.Black.copy(.12f), Color.Black.copy(.6f)))
            )
        )
        Column(Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 32.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(
                        "HOLA, ${words[p].uppercase()} ${name.uppercase()}",
                        color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        letterSpacing = 0.15.em
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(clock, color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Light)
                        Spacer(Modifier.width(16.dp))
                        Box(Modifier.width(1.dp).height(40.dp).background(Color.White.copy(.5f)))
                        Spacer(Modifier.width(16.dp))
                        Text(
                            date, color = Color.White, fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold, letterSpacing = 0.12.em
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Pill("Wi-Fi") { openSystem(ctx, true) }
                    Pill("Ajustes") { showCfg = true }
                }
            }
            Spacer(Modifier.weight(1f))
            Text(
                apps.getOrNull(cur)?.label ?: "", color = Color.White, fontSize = 40.sp,
                fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().height(300.dp).glass(30.dp)) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    itemsIndexed(apps) { i, a ->
                        Tile(a, if (i == 0) fr else null, { cur = i }, { launchApp(ctx, a.pkg) })
                    }
                }
            }
        }
    }
    if (showCfg) {
        CfgDialog(
            name, { showCfg = false },
            { name = it; prefs.edit().putString("nombre", it).apply() },
            { openSystem(ctx, false) }
        )
    }
}
